module Main where

import Text.Parsec
import Text.Parsec.Char
import Data.SBV

newtype Ingredient = Ingredient String
  deriving (Eq, Show)
newtype Allergen = Allergen String
  deriving (Eq, Show)
data Recipe = Recipe { ingredients :: [Ingredient]
                     , allergens :: [Allergen] }
  deriving (Eq, Show)

data Fact = Contains Ingredient Allergen deriving (Eq, Show)

recipeP :: Parsec String () Recipe
recipeP = do
  ingredients <- endBy ingredientP (char ' ')
  allergens <- between (char '(') (char ')') $ do
    string "contains "
    sepBy allergenP (string ", ")
  pure (Recipe ingredients allergens)
  where
    ingredientP = Ingredient <$> many1 lower
    allergenP = Allergen <$> many1 lower

main :: IO ()
main = do
  recipeStrings <- lines <$> readFile "input.txt"
  let Right recipes = traverse (parse recipeP "") recipeStrings
  print (length recipes)

recipeConstraints :: Recipe -> Symbolic SBool
recipeConstraints (Recipe ingredients allergens) = sAnd <$> sequence $ do
  allergen <- allergens
  sOr <$> sequence $ do
    ingredient <- ingredients
    sBool $ show (Contains ingredient allergen)
